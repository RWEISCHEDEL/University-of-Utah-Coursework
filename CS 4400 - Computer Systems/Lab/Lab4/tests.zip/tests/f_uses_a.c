extern int a[];

int f(int i) {
  return a[i];
}
