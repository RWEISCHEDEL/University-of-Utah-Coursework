package edu.utah.cs4530.networkbattleship;

/**
 * Created by Robert on 10/30/2016.
 */

public class Tile {
    public int xPos;
    public int yPos;
    public String status;
}
