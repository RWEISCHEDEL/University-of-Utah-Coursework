package edu.utah.cs4530.networkbattleship;

/**
 * Created by Robert on 10/30/2016.
 */

public class Game {
    public String name;
    public String status;
    public String id;
    public String player1;
    public String player2;
    public String winner;
    public int missilesLaunched;
    public String playerId;
    public String gameId;
}
