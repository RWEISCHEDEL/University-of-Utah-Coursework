/********************************
* Robert Weischedel
* CS 4480
* Assignment PA1 - Final
* 2/5/16
********************************/

Items In TarBall
readme.txt
NewClientConnection.java - Is a class that assists the accepting and handling of clients.
ProxyServer.java - Contains main method to start server.
pa1.jar


How to Complie and Run:

First way to run proxy - 
In the commandline type : "java -jar pa1_final.jar <port#>"

Then telnet into the localhost on the previously entered port number and then type away your commands!

Second way to run proxy -
Set your browers network connection HTTP proxy to be my proxys port number. 

And enter web addresses in the brower as you normally would.

*NOTE 

I had some issue with getting the JAR to work on the command line, but I believe I fixed it. If it doesn't work just import the .java files into eclipse and run it from there.



About the Proxy:
The proxy currently works on both command line and the web browser. But it will only work on the web 
browser if all the correct information browser setup info has been typed in. Like suggested in the 
assignment specifications for testing.

Source Code:
The code has been cleaned up and comments have been added.
