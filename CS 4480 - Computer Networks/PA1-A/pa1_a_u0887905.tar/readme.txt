/********************************
* Robert Weischedel
* CS 4480
* Assignment PA1 - A
* 1/31/16
********************************/

Items In TarBall
readme.txt
pa1.jar


How to Complie and Run:

In the commandline type : "java -jar .jar <port#>"

Then telnet into the localhost on the previously entered port number and then type away your commands!


Notes about the .java files (source code)
The code is still very ugly and needs some cleaning up, I haven't commented very much of it either. Just
so that you are aware. 

*It should also be noted that I have also completed next weeks portion that is due as well, becuase my 
Proxy is multithreaded as well and able to handle multiple requests.
