#!/bin/bash
python hw2.py
