This is the readme document for CS 6350 - Machine Learning HW 2

How to run:
Simply use run.sh to run my assignment. (I used python for the assignment)
Note: You are going to get alot of output comming at you from the screen.

Note: The accuracy values for the assignment are not good at all, I wrote up a description of what I think is going on in the PDF I turned in with the assignmnet. 
